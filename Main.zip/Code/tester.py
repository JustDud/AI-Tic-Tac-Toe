# # import numpy as np
# #
# # num_states = 5
# # num_actions = 5
# #
# # arr = np.zeros((num_states, num_actions))
# # dict = {}
# #
# # state1 = '001'
# # state2 = '002'
# #
# # action_index = 1
# # q_value = 1
# #
# # stateID = 1
# #
# #
# # dict[stateID] = state1
# # print(dict)
# # arr[stateID, action_index] = q_value
# #
# # print(arr[stateID, action_index])
# #
# #
# # def getStateFromDict(stateID):
# #     global dict
# #     return dict[stateID]
# #
# # print(getStateFromDict(1))
# #
# # print(dict.get(1))
# # a = 10
# # for i in range(a):
# #     print(i)
#
# # move2 = dict.get('0004')
# # print(move2)
# # if not move2:
# #     print('worked')
#
#
# # def split_list(lst, chunk_size):
# #     return [lst[i:i + chunk_size] for i in range(0, len(lst), chunk_size)]
# #
# #
# # def getNextState():
# #     currentState = '00001'
# #
# #     splitList = currentState.split('0')
# #     print(splitList)
# #
# #
# # getNextState()
# #
# # def split_number(number_str):
# #     return [int(digit) for digit in number_str]
# #
# # # Example usage:
# # number = "12345"
# # result = split_number(number)
# # print(result)
# #
# # if result[2] == 2:
# #     print("Worked")
#
# # import random
# #
# # list = []
# #
# #
# # def getList():
# #     return list
# #
# # def test():
# #     print(getList())
#
#
# # a = random.choice(getList())
# # print(a)
#
# # import time
# #
# # seconds = time.time()
# # print("Time in seconds since the epoch:", seconds)
# # local_time = time.ctime(seconds)
# # print("Local time:", local_time)
#
#
# import pygame
# import time
#
# def draw_text(surface, text, size, color, x, y):
#     font = pygame.font.Font(None, size)
#     text_surface = font.render(text, True, color)
#     text_rect = text_surface.get_rect(center=(x, y))
#     surface.blit(text_surface, text_rect)
#
# def stopwatch():
#     pygame.init()
#
#     # Set up Pygame display
#     screen_width, screen_height = 400, 200
#     screen = pygame.display.set_mode((screen_width, screen_height))
#     pygame.display.set_caption("Stopwatch")
#
#     clock = pygame.time.Clock()
#
#     start_time = time.time()
#     running = True
#
#     while running:
#         for event in pygame.event.get():
#             if event.type == pygame.QUIT:
#                 running = False
#
#         elapsed_time = time.time() - start_time
#         minutes, seconds = divmod(elapsed_time, 60)
#         hours, minutes = divmod(minutes, 60)
#         time_str = "{:02}:{:02}:{:02}".format(int(hours), int(minutes), int(seconds))
#
#         screen.fill((255, 255, 255))
#         draw_text(screen, "Elapsed Time", 30, (0, 0, 0), screen_width // 2, screen_height // 3)
#         draw_text(screen, time_str, 40, (255, 0, 0), screen_width // 2, screen_height // 2)
#
#         pygame.display.flip()
#         clock.tick(1)  # Update every second
#
#     pygame.quit()
#
# if __name__ == "__main__":
#     stopwatch()

# import matplotlib.pyplot as plt
#
# xAxis = [1, 2, 3, 4, 5, 6]
# yAxis = [2, 4, 1, 5, 2, 6]
#
# plt.rcParams['figure.figsize'] = [4.15, 2.5]
#
# plt.plot(xAxis, yAxis, color='red', linestyle='solid', linewidth=3, marker='o', markerfacecolor='blue', markersize=12)
#
# plt.ylim(1, 8)
# plt.xlim(1, 8)
#
# plt.xlabel('Win percentage')
# plt.ylabel('Number of games')
# plt.title('AI win rate')
#
# plt.show()

import matplotlib.pyplot as plt

def plotGraph():
    global multiplier
    global gameCounter
    global xAxis
    global yAxis
    global victoryNumAI
    global defeatNumAI
    global plotStep

    # # naming the x axis
    # plt.ylabel('Victory percentage')
    # # naming the y axis
    # plt.xlabel('Number of games')
    plt.title('Graph of Wins vs Number of Games')

    # setting x and y axis range
    plt.xlim(0, gameCounter)
    plt.ylim(0, 100)

    xAxis.append(plotStep * multiplier)

    plt.yticks([10, 20, 30, 40, 50, 60, 70, 80, 90, 100])

    ratio = victoryNumAI / gameCounter
    percentage = ratio * 100
    percentageStr = str(int(percentage))

    yAxis.append(percentage)

    plt.plot(xAxis, yAxis, color='red', linestyle='solid', linewidth=3, markersize=12)

    plt.legend(["Win percentage: "+percentageStr], loc="upper left")

    plt.savefig('graphWin.png')
    plt.show()


import pygame
import sys

# # Initialize Pygame
# pygame.init()
#
# # Set up display
# screen = pygame.display.set_mode((800, 600))
# pygame.display.set_caption("Flowchart Example")
#
# # Colors
# WHITE = (255, 255, 255)
# BLACK = (0, 0, 0)
#
# # Define nodes and edges
# nodes = {
#     'A': (100, 100),
#     'B': (300, 100),
#     'C': (300, 300),
#     'D': (500, 300),
#     'E': (300, 500),
# }
#
# edges = [('A', 'B', 'True'),
#          ('B', 'C'),
#          ('C', 'D', 'True'),
#          ('D', 'E'),
#          ('E', 'B')]
#
# # Main loop
# running = True
# while running:
#     for event in pygame.event.get():
#         if event.type == pygame.QUIT:
#             running = False
#
#     # Draw nodes
#     for node, pos in nodes.items():
#         pygame.draw.circle(screen, WHITE, pos, 20)
#         pygame.draw.circle(screen, BLACK, pos, 20, 2)
#         text = pygame.font.Font(None, 36).render(node, True, BLACK)
#         screen.blit(text, (pos[0] - 10, pos[1] - 10))
#
#     # Draw edges
#     for edge in edges:
#         start_pos = nodes[edge[0]]
#         end_pos = nodes[edge[1]]
#         pygame.draw.line(screen, BLACK, start_pos, end_pos, 2)
#         text = pygame.font.Font(None, 24).render(edge[1], True, BLACK)
#         text_rect = text.get_rect(center=((start_pos[0] + end_pos[0]) // 2, (start_pos[1] + end_pos[1]) // 2))
#         screen.blit(text, text_rect)
#
#     pygame.display.flip()
#
# pygame.quit()
# sys.exit()
#
#
# a = 1
# if a == 1:
#     if a == 1:
#         if a == 1:
#             # button 4
#             if buttonXcoord <= mouse[0] <= buttonXcoord + buttonWidth and buttonYcoord + 3 * spacing <= mouse[1] <= buttonYcoord + buttonHeight + 3 * spacing:
#                 if not button4:
#                     button4 = True
#                     userStateID = int(input("Enter ID of the state you want to see the Q Table for: "))
#                     if userStateID >= 0:
#                         if userStateID <= stateID:
#                             print(q_valuesAI[userStateID])
#                         else:
#                             print("\nInvalid value")
#                     else:
#                         print("\nInvalid value")
#                     button4 = False
#
# if a == 1:
#     if a == 1:
#         if a == 1:
#             # button 4
#             if buttonXcoord <= mouse[0] <= buttonXcoord + buttonWidth and buttonYcoord + 3 * spacing <= mouse[1] <= buttonYcoord + buttonHeight + 3 * spacing:
#                 if not button4:
#                     button4 = True
#                     # loop to ask user for an input and validate it, till button is pressed
#                     while button4:
#                         userStateID = int(input("Enter ID of the state you want to see the Q Table for: "))
#                         if userStateID >= 0:
#                             if userStateID <= stateID:
#                                 print(q_valuesAI[userStateID])
#                                 print("")
#                             else:
#                                 print("State with entered id does not exist, try again")
#                                 print("")
#                         else:
#                             print("Invalid value, try again")
#                         if button4:
#                             button4 = False
#
# if a == 1:
#     if a == 1:
#         if a == 1:
#             # button 4
#             if buttonXcoord <= mouse[0] <= buttonXcoord + buttonWidth and buttonYcoord + 3 * spacing <= mouse[1] <= buttonYcoord + buttonHeight + 3 * spacing:
#                 if not button4:
#                     button4 = True
#                     stop = False
#                     # loop to ask user for an input and validate it, till exit command is given
#                     while not stop:
#                         print("Number of unique states:", stateID)
#                         userStateID = int(input("Enter ID of the state you want to see the Q Table for or -1 to exit: "))
#                         if userStateID == -1:
#                             print("You may return back to settings")
#                             stop = True
#                         elif userStateID >= 0:
#                             if userStateID <= stateID:
#                                 print(q_valuesAI[userStateID])
#                                 print("")
#                             else:
#                                 print("State with entered id does not exist, try again or enter -1 to exit")
#                                 print("")
#                         else:
#                             print("\nInvalid value, try again. Enter -1 to exit without making any changes\n")
#                     button4 = False
#
# if a == 1:
#     if a == 1:
#         if a == 1:
#             # button 4
#             if buttonXcoord <= mouse[0] <= buttonXcoord + buttonWidth and buttonYcoord + 3 * spacing <= mouse[1] <= buttonYcoord + buttonHeight + 3 * spacing:
#                 if not button4:
#                     button4 = True
#                     stop = False
#                     # loop to ask user for an input and validate it, till exit command is given
#                     while not stop:
#                         try:
#                             print("Number of unique states:", stateID)
#                             userStateID = int(input("Enter ID of the state you want to see the Q Table for or -1 to exit: "))
#                             if userStateID == -1:
#                                 print("You may return back to settings")
#                                 break
#                             elif userStateID >= 0:
#                                 if userStateID <= stateID:
#                                     print(q_valuesAI[userStateID])
#                                     print("")
#                                 else:
#                                     print("State with entered id does not exist, try again or enter -1 to exit")
#                                     print("")
#                             else:
#                                 print("\nInvalid value, try again. Enter -1 to exit without making any changes\n")
#                         except ValueError:
#                             print("\nInvalid id, try again. Enter -1 to exit\n")
#                     button4 = False



# if plotStep * multiplier == gameCounter THEN
#     plotGraph()
#
# function plotGraph()
#     global gameCounter
#     global multiplier
#     global victoryNumAI
#     global xAxis
#     global yAxis
#     xAxis.append(plotStep * multiplier)
#     ratio = victoryNumAI / gameCounter
#     percentage = ratio * 100
#     yAxis.append(pecentage)
#     multiplier = multipler + 1






